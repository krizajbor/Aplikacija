package org.appinventor;
import com.google.appinventor.components.runtime.HandlesEventDispatching;
import com.google.appinventor.components.runtime.EventDispatcher;
import com.google.appinventor.components.runtime.Form;
import com.google.appinventor.components.runtime.Component;
import com.google.appinventor.components.runtime.VerticalArrangement;
import com.google.appinventor.components.runtime.Label;
import com.google.appinventor.components.runtime.HorizontalArrangement;
import com.google.appinventor.components.runtime.Image;
import com.google.appinventor.components.runtime.Clock;
class Screen1 extends Form implements HandlesEventDispatching {
  private VerticalArrangement VerticalArrangement1;
  private Label Naslov;
  private HorizontalArrangement Blazilec_pred_sliko;
  private Image Slika;
  private HorizontalArrangement Blazilec_po_sliki;
  private Label Kraj;
  private Clock Clock1;
  protected void $define() {
    this.AlignHorizontal(3);
    this.AlignVertical(2);
    this.AppName("Pohod po sledeh soške fronte");
    this.Icon("Tabla1.jpg");
    this.Title("Screen1");
    VerticalArrangement1 = new VerticalArrangement(this);
    VerticalArrangement1.AlignHorizontal(3);
    VerticalArrangement1.AlignVertical(2);
    VerticalArrangement1.Height(-1080);
    VerticalArrangement1.Width(-1090);
    Naslov = new Label(VerticalArrangement1);
    Naslov.FontBold(true);
    Naslov.FontSize(22);
    Naslov.Text("Pohod \npo sledeh soške fronte");
    Blazilec_pred_sliko = new HorizontalArrangement(VerticalArrangement1);
    Blazilec_pred_sliko.Height(-1005);
    Slika = new Image(VerticalArrangement1);
    Slika.Width(-1080);
    Slika.Picture("Tabla1.jpg");
    Blazilec_po_sliki = new HorizontalArrangement(VerticalArrangement1);
    Blazilec_po_sliki.Height(-1005);
    Kraj = new Label(VerticalArrangement1);
    Kraj.FontBold(true);
    Kraj.FontSize(18);
    Kraj.Text("Brestovica pri Komnu");
    Clock1 = new Clock(this);
  }
  public boolean dispatchEvent(Component component, String componentName, String eventName, Object[] params){
    return false;
  }
}